import importlib.resources as pkg_resources
import os
import shutil

from inspyre_toolbox.path_man import provision_path
from rich.console import Console

from ipyboost.cli.installer import MOD_LOGGER

# Initialize rich console.
CONSOLE = Console()

# Create colorized operation labels.
CREATE = '[green][bold]create[/bold][/green]'
COPY = '[yellow][bold]copy[/bold][/yellow]'
COPIED = '[green][bold]Copied[/bold][/green]'
COPYING = '[yellow][bold]Copying[/bold][/yellow]'


def c_print(message):
    CONSOLE.print(message)


def format_path(path):
    return f'[magenta][italic]{path}[/magenta][/italic]'


def format_output(message):
    message.replace('copy', f'{COPY}')
    message.replace('create', f'{CREATE}')


def copy_file(src, dest, dry_run=False, allow_overwrite=False):
    """ Copy a file from the source to the destination path.

    Parameters:
        src (str):
            The source file to copy.

        dest (str):
            The destination path to copy the file to.

        dry_run (bool):
            If True, the function will not copy any files and will only log the operations.

        allow_overwrite (bool):
            If True, the function will overwrite any existing files in the destination directory.

    Returns:
        None

    Raises:
        FileNotFoundError:
            If the source file does not exist.

        FileExistsError:
            If the destination file already exists and allow_overwrite is False.
    """
    log = MOD_LOGGER.get_child('copy_file')

    src = provision_path(src)
    src_formatted = format_path(src)
    src_name = src.name

    if not src.exists():
        raise FileNotFoundError(f'File not found: {src_formatted}')

    dest = provision_path(dest)
    dest_formatted = format_path(dest)

    if dest.exists() and not allow_overwrite:
        raise FileExistsError(f'File already exists: {dest_formatted} (use "allow_overwrite=True" to overwrite)')

    log.debug(f'{COPYING} {src_name} to {dest_formatted}')

    if dry_run:
        log.info(f'Would {COPY} {src_name} to {dest_formatted}')
    else:
        shutil.copy(src, dest)
        log.debug(f'{COPIED} {src_name} to {dest_formatted}')


def copy_startup_scripts(dry_run=False, updating=False):
    """
    Copy the IPython startup scripts to the IPython profile startup directory.

    Parameters:
        dry_run (bool):
            If True, the function will not copy any files and will only log the operations.

        updating (bool):
            If True, the function will overwrite any existing files in the destination directory.

    Returns:
        None
    """
    log = MOD_LOGGER.get_child('copy_startup_scripts')

    # Target directory (IPython profile startup)
    ipython_startup_dir = provision_path(os.path.expanduser("~/.ipython/profile_default/startup"))
    ipython_startup_dir_formatted = format_path(ipython_startup_dir)

    log.debug(f'{COPYING} startup scripts to {ipython_startup_dir_formatted}')

    if not os.path.exists(ipython_startup_dir):
        if dry_run:
            log.info(f'Would {CREATE} directory: {ipython_startup_dir_formatted}')
        else:
            os.makedirs(ipython_startup_dir, exist_ok=True)
            log.debug(f'Created directory: {ipython_startup_dir_formatted}')

    # Get the directory as a Traversable object using `files()` and filter for Python files
    script_directory = pkg_resources.files('ipyboost.starters.scripts')

    # Traverse the directory and copy the relevant files
    for script in script_directory.iterdir():
        if script.suffix in ['.py', '.ipy']:
            dest_path = provision_path(os.path.join(ipython_startup_dir, script.name))

            try:
                copy_file(script, dest_path, dry_run=dry_run, allow_overwrite=updating)
            except FileExistsError as e:
                log.warning(e)
                continue
