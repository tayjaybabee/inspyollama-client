import os
from pathlib import Path

# Find the startup directory for iPython
IPYTHON_STARTUP_DIR = Path.home().joinpath('.ipython/profile_default/startup')

# Ensure it exists
os.makedirs(IPYTHON_STARTUP_DIR, exist_ok=True)
