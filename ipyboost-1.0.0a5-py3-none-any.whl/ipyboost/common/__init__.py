"""


Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/common/__init__.py
 

Description:
    

"""
