"""


Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/common/console.py
 

Description:
    

"""
from rich.console import Console

CONSOLE = Console()
