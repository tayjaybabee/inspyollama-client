"""
Author:
    Inspyre Softworks
0-p[87
Project:
    iPyBoost

File:
    ipyboost/dev_tools/helpers/system.py

Description:
    This file contains helper functions for interacting with the operating system.

Since:
    v1.0
"""
import os
from pathlib import Path
from subprocess import Popen, PIPE
from ipyboost.common.console import CONSOLE
from ipyboost.log_engine import ROOT_LOGGER


MOD_LOGGER = ROOT_LOGGER.get_child('dev_tools.helpers.system')


def execute_command(
        command,
        cwd=None,
        as_bytes=False,
        raise_on_error=False
):
    log = MOD_LOGGER.get_child('execute_command')

    if not cwd:
        log.debug(f'No working directory provided. Using current working directory ({os.getcwd()}).')

        cwd = Path('.').resolve()

    proc = Popen(
        command,
        cwd=cwd,
        stdout=PIPE,
        stderr=PIPE,
        shell=True,
        text=not as_bytes
    )
    stdout, stderr = proc.communicate()
    if raise_on_error and proc.returncode:
        raise RuntimeError(
            f'Command "{command}" failed with error code {proc.returncode}'
        )

    return stdout, stderr, proc.returncode


def execute_command_and_print(command, printer=CONSOLE.print, **kwargs):
    """
    Execute a given command and print the output.

    Parameters:

        command:
            The command to execute.

        printer:
            The printer to use to print the output.

        **kwargs:
            Additional keyword arguments to pass to the execute_command function.

    Returns:
        None

    Raises:

        RuntimeError:
            If the command fails and the raise_on_error flag is set.

    """
    if printer is None:
        printer = print

    stdout, stderr, return_code = execute_command(command, **kwargs)

    printer = printer

    if stdout:
        printer(stdout)

    if stderr:
        printer(stderr)

    if return_code:
        printer(f'Command "{command}" returned error code {return_code}')
