"""


Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/dev_tools/scripts/version/constants.py
 

Description:
    

"""
from importlib.resources import files

PYPROJECT_FILE = 'pyproject.toml'

VERSION_FILE = files('ipyboost.meta.version').joinpath('VERSION')

BUMP_TYPES = [
    'patch',
    'minor',
    'major',
    'prepatch',
    'preminor',
    'premajor',
    'prerelease'
]
