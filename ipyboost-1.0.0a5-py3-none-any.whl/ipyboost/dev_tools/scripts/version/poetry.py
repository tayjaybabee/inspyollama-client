"""
Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/dev_tools/scripts/version/poetry.py

Description:
    This module contains the functions for versioning the project. It is used to read and write the pyproject.toml file,
    and to bump the version number.
"""
from inspy_logger import InspyLogger
from packaging.version import parse as parse_version
from subprocess import Popen, PIPE
from typing import Optional, Union
from pathlib import Path

import toml
from inspyre_toolbox.path_man import provision_path

from ipyboost.dev_tools.scripts.version.constants import PYPROJECT_FILE, BUMP_TYPES
from os import getcwd


PYPROJECT_FILE = Path(PYPROJECT_FILE).resolve().joinpath('../../../../../pyproject.toml').resolve()

BUMP_COMMAND = 'poetry version'

LOGGER = InspyLogger('iPyBoost.Scripts.Version.lib.poetry')


def read_pyproject_file(
        pyproject_file:   Optional[Union[Path, str]]=PYPROJECT_FILE,
        do_not_provision: bool = False,
        do_not_convert:   bool = False
) -> dict:
    """
    Read the pyproject.toml file.

    Note:
        Passing an object to :param:`pyproject_file` that is not a Path object while also setting `do_not_convert` to
        `True` will raise a `TypeError`.

    Parameters:

        pyproject_file (Optional[Union[Path, str]]):
            The path to the pyproject.toml file. (Optional, defaults to :const:`PYPROJECT_FILE`.)

        do_not_provision:
            If True, do not provision the path. (Optional, defaults to :bool:`False`.)

        do_not_convert:
            If True, do not convert the path to a Path object. (Optional, defautls to :bool:`False`.)

    Returns:
        The pyproject.toml file as a dictionary. (Type: :class:`dict`.)

    """
    log = LOGGER.get_child('read_pyproject_file')
    log.debug(f'Received the following for the "pyproject_file" parameter: {pyproject_file}')

    fp = pyproject_file

    if not do_not_provision:
        log.debug('Provisioning path.')
        fp = provision_path(pyproject_file)

    if not isinstance(fp, Path):
        log.error(f'Invalid path type: {fp}')
        raise TypeError(f"Invalid path: {fp}")


    with open(fp, 'r') as file:
        pyproject = toml.load(file)

    return pyproject


def get_project_version_from_toml(**kwargs):
    """
    Get the project version from the pyproject.toml file.

    Parameters:
        **kwargs:
            Additional keyword arguments to pass to the :func:`read_pyproject_file` function.

    Returns:
        str:
            The project version.
    """
    pyproject_dict = read_pyproject_file(**kwargs)

    return pyproject_dict['tool']['poetry']['version']


def send_bump_command(bump_rule: str):
    """
    Send the poetry bump command to the system.

    Parameters:
        bump_rule (str):
            The bump rule to apply. Must be one of the following:
                - patch
                - minor
                - major
                - prepatch
                - preminor
                - premajor
                - prerelease

    Returns:
        Tuple[str, str, int]:
            The standard output, standard error, and return code of the command.

    """
    p = Popen(
        f'{BUMP_COMMAND} {bump_rule}',
        stdout=PIPE,
        stderr=PIPE,
        shell=True
    )
    p.wait()

    return p.stdout, p.stder, p.returncode


def bump_version(
        bump_type:        str,
        pyproject_file:   Optional[Union[str, Path]] = PYPROJECT_FILE,
        do_not_provision: bool = False,
        do_not_convert:   bool = False,
        case_sensitive:   bool = False
):
    """
    Bump the version in the pyproject.toml file.

    The following bump types are supported:
        - patch
        - prepatch
        - minor
        - preminor
        - major
        - premajor
        - release
        - prerelease

    Parameters:
        bump_type (str):
            The type of bump to perform.

        pyproject_file:
            The path to the pyproject.toml file. (Optional, defaults to :const:`PYPROJECT_FILE`.)
    """
    if not case_sensitive:
        bump_type = bump_type.lower()

    if bump_type not in BUMP_TYPES:
        raise ValueError(f'Invalid bump type: {bump_type}. Must be one of: {",".join(BUMP_TYPES)}')

    cur_ver = parse_version(get_project_version_from_toml(pyproject_file))

    stdout, stderr, returncode = send_bump_command(bump_type)

    send_bump_command(bump_type)
    new_ver = parse_version(get_project_version_from_toml(pyproject_file))

    if cur_ver == new_ver:
        raise ValueError(f"Failed to bump version: {cur_ver} -> {new_ver}")

    if cur_ver > new_ver:
        raise ValueError(f"Version was downgraded: {cur_ver} -> {new_ver}")


def write_pyproject_file(
        data: dict,
        pyproject_file: Optional[Union[str, Path]] = PYPROJECT_FILE,
):
    """
    Write the pyproject.toml file.

    Parameters:
        data (dict):
            The data to write to the file.

        pyproject_file (Union[str, Path]:
            The path to the pyproject.toml file. (Optional, defaults to :const:`PYPROJECT_FILE`.)
    """
    with open(pyproject_file, 'w') as file:
        toml.dump(data, file)


def write_version_file(
        file_path: Union[str, Path],
        version_string: Optional[str] = None,
        pyproject_file: Optional[Union[str, Path]] = PYPROJECT_FILE,
        do_not_provision: bool = False,
        do_not_convert: bool = False,
        create_new: bool = False,
):
    """
    Write the version string to a file.

    Parameters:
        file_path (Union[str, Path]):
            The path to the file to write to.

        version_string (str):
            The version string to write to the file. (Optional, defaults to the version string from the pyproject.toml file.)

        pyproject_file (Optional[Union[str, Path]]):
            The path to the pyproject.toml file. (Optional, defaults to :const:`PYPROJECT_FILE`.)

        do_not_provision (bool):
            If True, do not provision the path. (Optional, defaults to :bool:`False`.)

        do_not_convert (bool):
            If True, do not convert the path to a Path object. (Optional, defaults to :bool:`False`.)

        create_new (bool):
            If True, create a new file if the file does not exist. (Optional, defaults to :bool:`False`.)

    Returns:
        None

    Raises:
        ValueError:
            If the version string is not valid.

        FileNotFoundError:
            If the file path is not valid.

        TypeError:
            If the file path is not a string or a Path object.

        PermissionError:
            If the file path is not writable.

        OSError:
            If the file path is not valid.

    """
    log = LOGGER.get_child('write_version_file')
    if not version_string:
        log.debug('No version string provided. Getting version string from pyproject.toml file.')
        if not pyproject_file:
            log.warning(f'No pyproject file provided. Using default: {PYPROJECT_FILE}')
            pyproject_file = PYPROJECT_FILE
        else:
            log.debug(f'Using provided pyproject file: {pyproject_file} (provided by caller')
            pyproject_file = pyproject_file

        log.debug(f'Getting project version from pyproject file: {pyproject_file}')
        version_string = get_project_version_from_toml(pyproject_file=pyproject_file)

    log.debug(f'Getting project version file: {file_path}.')
    if not do_not_provision:
        log.debug(f'Provisioning path: {file_path}')
        file_path = provision_path(file_path)
        log.debug(f'Provisioned path: {file_path}')
    else:
        log.debug(f'Not provisioning path: {file_path}')

    log.debug('Checking if path is a Path object.')

    if not do_not_convert:
        file_path = Path(file_path)

    if (not file_path.exists() or not file_path.is_file()) and not create_new:
        log.error(f'Invalid file path: {file_path}')
        raise FileNotFoundError(f"Invalid file path: {file_path}")
    elif create_new and (not file_path.exists() or not file_path.is_file()):
        log.debug(f'Creating new file: {file_path}')
        file_path.touch()

    log.debug(f'Writing version string ({version_string}) to file: {file_path}')

    with open(file_path, 'w') as file:
        file.write(version_string)

    log.debug(f'Wrote version string to file: {file_path}')
