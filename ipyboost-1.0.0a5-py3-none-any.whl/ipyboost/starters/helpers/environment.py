import sys

from ipyboost.starters.helpers import MOD_LOGGER as PARENT_LOGGER

# Set up the logger for this module.
MOD_LOGGER = PARENT_LOGGER.get_child('environment')

EXE = sys.executable
PIP_CMD = f'{EXE} -m pip'

__all__ = ['EXE', 'PIP_CMD']
