import subprocess
from typing import Optional, Union

from ipyboost.common.console import CONSOLE
from ipyboost.starters.helpers import MOD_LOGGER as PARENT_LOGGER

MOD_LOGGER = PARENT_LOGGER.get_child('system')


def open_directory(directory: str):
    """
    Open a directory in the system's file explorer.

    Parameters:
        directory (str):
            The directory to open.
    """
    import subprocess

    try:
        subprocess.run(f'explorer {directory}', shell=True)
    except subprocess.CalledProcessError as e:
        PARENT_LOGGER.error(f"Error opening directory: {e}")


def run_system_command(
        command: str,
        return_output: bool = False,
        return_code: bool = False,
) -> Optional[Union[str, int]]:
    """
    Executes a system command and returns either None, the output, or the return code based on the given options.

    Parameters:
        command (str):
            The system command to execute.

        return_output (bool):
            If True, returns the output of the command.

        return_code (bool):
            If True, returns the return code of the command. the command.

    Returns:
        - None if neither return_output nor return_code is True.
        - The output of the command as a string if return_output is True.
        - The return code as an int if return_code is True.
    """
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)

        if return_output:
            return result.stdout.strip()
        elif return_code:
            return result.returncode
        else:
            return None

    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {e}")
        return None


def run_command_and_print(
        command: str,
        **kwargs,
):
    """
    Run a command and print the output to the console.

    Parameters:
        command (str):
            The command to run.

        **kwargs:
            Additional keyword arguments to pass to the run_system_command function.

    Returns:
        Optional[Union[str, int]]:
            The output of the command if return_output is True; otherwise, None.

    """
    log = MOD_LOGGER.get_child('run_command_and_print')

    output = run_system_command(command, **kwargs)

    if output:
        CONSOLE.print(output)
    else:
        log.warning(f"No output from command: {command}")

        return None

    return output
