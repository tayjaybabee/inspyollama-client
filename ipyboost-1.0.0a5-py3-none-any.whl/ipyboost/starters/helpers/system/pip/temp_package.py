"""
Author: Taylor B. tayjaybabee@gmail.com
Date: 2024-10-21 21:57:31
LastEditors: Taylor B. tayjaybabee@gmail.com
LastEditTime: 2024-10-21 22:01:16
FilePath: ipyboost/starters/helpers/system/pip/temp_package.py
Description: 这是默认设置,可以在设置》工具》File Description中进行配置
"""
import atexit
from ipyboost.starters.helpers.system.pip import Pip


class TemporaryPackageManifest:
    INSTALLER = Pip.install
    UNINSTALLER = Pip.uninstall
    
    def __init__(self):
        self.packages = []

    def add_package(self, package_name):
        self.packages.append(package_name)

    def remove_package(self, package_name):
        self.packages.remove(package_name)

    def uninstall_all_temp_packages(self):
        for package in self.packages:
            self.UNINSTALLER(package)
