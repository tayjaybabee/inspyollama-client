import sys
from os import system
from shutil import which

from inspyre_toolbox.path_man import provision_path

from ipyboost.starters.helpers.environment import PIP_CMD


class Pip:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(Pip, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_initialized'):
            self.__location = which('pip')  # You might want to set this based on the current environment
            self.__lib = provision_path(f'{sys.prefix}\Lib\site-packages')
            self._initialized = True

    @property
    def pip_location(self):
        """Return the pip location."""
        return self.__location

    @property
    def lib_location(self):
        """Return the library location."""
        return self.__lib

    @property
    def script_location(self):
        """Return the script location if set."""
        return self.__location

    @script_location.setter
    def script_location(self, location: str):
        """Set the script location."""
        self.__location = location

    def install(self, package: str):
        """Install a package using pip."""
        result = system(f'{PIP_CMD} install {package}')
        if result != 0:
            raise RuntimeError(f'Failed to install package: {package}')

    def uninstall(self, package: str):
        """Uninstall a package using pip."""
        result = system(f'{PIP_CMD} uninstall -y {package}')  # Added -y to skip confirmation
        if result != 0:
            raise RuntimeError(f'Failed to uninstall package: {package}')

    def upgrade(self, package: str):
        """Upgrade a package using pip."""
        result = system(f'{PIP_CMD} install --upgrade {package}')
        if result != 0:
            raise RuntimeError(f'Failed to upgrade package: {package}')

    def list(self):
        """
        List all installed packages.

        Returns:

        """
        system(f'{PIP_CMD} list')

    def find_installed(self, package: str):
        """
        Find an installed package.

        Parameters:
            package (str):
                The package to search for.

        Returns:
            bool:
                True if the package is installed; otherwise, False.
        """
        return system(f'{PIP_CMD} list | grep {package}') == 0

    def check_if_installed(self, package: str) -> bool:
        """
        Check if a package is installed.

        Parameters:
            package (str):
                The package to check.

        Returns:
            bool:
                True if the package is installed; otherwise, False.
        """
        return system(f'{PIP_CMD} show {package}') == 0

    def check_if_latest(self, package: str) -> bool:
        """
        Check if a package is up to date.

        Parameters:
            package (str):
                The package to check.

        Returns:
            bool:
                True if the package is up to date; otherwise, False.
        """
        # To check if the package is latest, we can compare versions
        return system(f'{PIP_CMD} install --upgrade {package}') == 0
