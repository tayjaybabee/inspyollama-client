# ~/.ipython/profile_default/startup/02-auto-debug.py
import sys


def custom_excepthook(type, value, tb):
    import traceback, pdb
    traceback.print_exception(type, value, tb)
    pdb.post_mortem(tb)


sys.excepthook = custom_excepthook
