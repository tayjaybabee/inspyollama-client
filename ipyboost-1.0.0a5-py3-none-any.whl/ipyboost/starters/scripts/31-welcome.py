import pyfiglet


def welcome():
    print(pyfiglet.figlet_format('Welcome to IpyBoost!'))
    print(pyfiglet.figlet_format('with IpyBoost!', font='slant'))


welcome()
