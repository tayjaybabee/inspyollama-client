"""
Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/starters/scripts/00-system.py
 

Description:
    IPython startup script to load system utilities and helpers.
"""
from ipyboost.log_engine import ROOT_LOGGER, Loggable

MOD_LOGGER = ROOT_LOGGER.get_child('startup_scripts.system')


class Process(Loggable):
    """
    A simple class to manage processes.
    """

    @property
    def processes(self):
        """
        Get all running processes.
        """
        return get_processes()
