from ipyboost.log_engine import ROOT_LOGGER

MOD_LOGGER = ROOT_LOGGER.get_child('starters')
