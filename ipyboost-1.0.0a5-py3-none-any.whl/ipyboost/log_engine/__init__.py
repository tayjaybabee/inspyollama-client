from inspy_logger import InspyLogger, Loggable

ROOT_LOGGER = InspyLogger('ipyboost', console_level="DEBUG", no_file_logging=True)

MOD_LOGGER = ROOT_LOGGER.get_child('log_engine')

# Announce the module's initialization

MOD_LOGGER.debug('Started program loggers.')
