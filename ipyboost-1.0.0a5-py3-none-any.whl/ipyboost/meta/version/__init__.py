"""


Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/meta/version/__init__.py
 

Description:
    

"""
