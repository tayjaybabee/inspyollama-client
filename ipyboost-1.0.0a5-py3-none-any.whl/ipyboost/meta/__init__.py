"""


Author: 
    Inspyre Softworks

Project:
    iPyBoost

File: 
    ipyboost/meta/__init__.py
 

Description:
    

"""
